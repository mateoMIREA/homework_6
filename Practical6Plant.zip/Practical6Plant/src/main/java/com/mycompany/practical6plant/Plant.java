/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.practical6plant;

import java.io.BufferedReader;
import java.io.Externalizable;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

/**
 *
 * @author М_З_А
 */
public class Plant implements Externalizable {
    private String name;
    private String area;
    private int age;
    transient private int height;
    private String color;

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeObject(name);
        out.writeObject(area);
        out.writeInt(age);
        out.writeObject(color);
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        name = (String) in.readObject();
        area = (String) in.readObject();
        age = in.readInt();
        color = (String) in.readObject();
    }

    public void saveToFile() {
        String fileName = "C:\\plant.ser";
        try (OutputStream fileOutputStream = new FileOutputStream(fileName);
             ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream)) {
            objectOutputStream.writeObject(this);
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Ваше растение было сохранено в: " + fileName);
    }

    public void fillFields() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Практика №6, Вариант 4, Новиков М.С., РИБО-01-21");
        System.out.print("Введите название растения: ");
        name = reader.readLine();
        System.out.print("Введите зону произрастания растения: ");
        area = reader.readLine();
        System.out.print("Введите возраст растения: ");
        age = Integer.parseInt(reader.readLine());
        System.out.print("Введите высоту растения: ");
        height = Integer.parseInt(reader.readLine());
        System.out.print("Введите цвет растения: ");
        color = reader.readLine();
    }

    public static void main(String[] args) throws IOException {
        Plant plant = new Plant();
        plant.fillFields();
        new Thread(() -> plant.saveToFile()).start();
    }
}
