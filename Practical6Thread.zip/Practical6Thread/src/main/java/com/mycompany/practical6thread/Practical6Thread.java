/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.practical6thread;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author М_З_А
 */
public class Practical6Thread {

    public static void main(String[] args) throws FileNotFoundException {
        System.out.println("Практическая работа №6, вариант 4, Новиков М.С., РИБО-01-21");
        
        String nm, ar, col;
        int ag;
        double hg;
        
        System.out.println("Введите название растения: ");
        nm = scan();
        System.out.println("Введите зону произрастания растения: ");
        ar = scan();
        System.out.println("Введите цвет растения: ");
        col = scan();
        System.out.println("Введите возраст растения: ");
        ag = Integer.parseInt(scan());
        System.out.println("Введите высоту растения: ");
        hg = Double.parseDouble(scan());
        
        Plant plant = new Plant(nm,ar,col,ag,hg);
    
    File file = new File("C:\\Novikov\\FinObj.txt");
        SaverRunnable saver = new SaverRunnable(plant, "C:\\Novikov\\FinObj.txt");
        Thread thread = new Thread(saver);
        thread.start();
        System.out.println("Ваше растение было сохранено в: " + file);
    }

    public static String scan() {
        return new Scanner(System.in).nextLine();
    }
}
