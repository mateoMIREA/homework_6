/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practical6thread;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 *
 * @author М_З_А
 */
public class Plant implements Externalizable{
    private String name;
    private String area;
    private String color;
    private int age;
    private double height;

    public Plant(String name, String area, String color, int age, double height) {
        this.name = name;
        this.area = area;
        this.color = color;
        this.age = age;
        this.height = height;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public Plant() {}

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeObject(this.getName());
        out.writeObject(this.getArea());
        out.writeObject(this.getColor());
        out.writeObject(this.getAge());
        out.writeObject(this.getHeight());
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        this.name = (String)in.readObject();
        this.area = (String)in.readObject();
        this.color = (String)in.readObject();
        this.age = (Integer)in.readObject();
        this.height = (Double)in.readObject();
    }

    @Override
    public String toString(){
        return "Растение " + getName() + ", зона произрастания: " + getArea() + ", цвет: " + getColor() + ", возраст (в годах)" + getAge() + ", высота" + getHeight();
    }
}
