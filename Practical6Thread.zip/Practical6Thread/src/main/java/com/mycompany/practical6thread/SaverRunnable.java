/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practical6thread;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

/**
 *
 * @author М_З_А
 */
public class SaverRunnable implements Runnable{

    private Plant plant;
    private String path;

    public SaverRunnable(Plant plant, String path) {
        this.plant = plant;
        this.path = path;
    }

    public Plant getPlant() {
        return plant;
    }

    public void setPlant(Plant plant) {
        this.plant = plant;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
    
    
    
    @Override
    public void run() {
        if (plant != null && path != null) {
            FileOutputStream fos;
            try {
                fos = new FileOutputStream(path);
                ObjectOutputStream oos = new ObjectOutputStream(fos);
                oos.writeObject(this);
                oos.close();
                System.out.println("Растение успешно сериализовано!");
            } catch (IOException e) {
                System.out.println("Ошибка, не удалось сохранить растение в файл!");
            }
        }
    }
    
}
